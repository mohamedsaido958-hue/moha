import { useState, useEffect, useRef, type ReactNode } from 'react';
import {
  MapPin, Phone, Clock, Star,
  Menu as MenuIcon, X, MessageCircle, Camera, Coffee,
  UtensilsCrossed, ArrowRight,
  Waves, Heart, Award, ChevronDown,
  Quote, Sparkles
} from 'lucide-react';

/* Inline SVG social icons */
function InstagramIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

function FacebookIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  );
}

/* ──────────── CONSTANTS ──────────── */
const WHATSAPP_NUMBER = '212600000000';
const PHONE_DISPLAY = '0600000000';
const WHATSAPP_BASE = `https://wa.me/${WHATSAPP_NUMBER}`;
const MAPS_URL = 'https://maps.app.goo.gl/y7AD4KLXZQ9ous8q9';
const ADDRESS = 'C99W+G6W, Boulevard du 20 Aout, Agadir 80000';
const HERO_IMG =
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779113993/imgi_24_AF1QipOAdL-TgdHCJoBWQETbrPOlGtIWMVbRx7rrTeT2_s677-k-no_mmbi0v.jpg';

const waLink = (text?: string) =>
  `${WHATSAPP_BASE}?text=${encodeURIComponent(text || 'Bonjour ! Je souhaite avoir des informations sur Côté Plage.')}`;

/* ──────────── GALLERY IMAGES ──────────── */
const GALLERY_IMAGES = [
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779113993/imgi_24_AF1QipOAdL-TgdHCJoBWQETbrPOlGtIWMVbRx7rrTeT2_s677-k-no_mmbi0v.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114836/imgi_88_APNQkAHaQnhdk7R8i2Yb4a0crWqvfsc4tM_e2EwTkMX2Hl_gv7HKeJPSQOZ5FdXR-kyhhMPZc3ScT817Ry76Jt5_RvQWTtzzYx3hsf4xhNOcTMfd3ixInW-SBFeLHxtq94eFOqdjxD2gcV3YXfvy_s508-k-no_n2rckn.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114813/imgi_31_AF1QipP2kiCHSX1NNT6p9-oPj8_hsanArZTQBIf6RMs1_w203-h250-k-no_mcaztm.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114816/imgi_36_APNQkAHZAjFe8azo2NAzXXO-Em0bCL9twjlj3WV8jO5Ossl-UNWddcpKpoqTjnCipsjghvaPp8CECsIcqBG2DSceDGoB4HWEK1k-JLrwiKZhypdo1v82Vw2CXCm8tr2HGilQmnLxUVvV2DiStfhk_s387-k-no_mqnusa.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114821/imgi_52_APNQkAHK_atRSUItYRhDpdQJqeqCNjpYnIEpIvJCIYJGNz0GQRl5Q1Qnj9HaCoQV550sDICuXdxWOXRJGjUfJY0bjOdRXq15HXFhHm5_wwxVG1JKyadu7cx9JROEAThevLoDlBxg2m4nGhV3SU9E_s677-k-no_pfbqe5.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114823/imgi_56_APNQkAG_AaWavciiztjsgjjtbG_Urh1VVl3ky9YaNI2Aq35xxyo1qNxKz9EAmW83UbvVChwUkZ5zvcpogsmhvs9PNhK7LRDZnlxHhYZImh0Ellxgu9BwRK7-br1XMI_eiZUeqmVp4BQpBV5q3c-B_s406-k-no_fruqpc.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114829/imgi_43_APNQkAFBdrwzYJ-SA-922weJ_UP3Wyohx2emd8LVJ7N_v3Jz_43hYAol1DyV0L8qmWDQBAGamz7NV6o_fYdLtaYBjLUTiIViFxlktGRC8ANG6XdevZy6W4J4EL8WbpBxL4I9a10f8GYfQ_6al9Zj_s406-k-no_zav1si.png',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114830/imgi_62_APNQkAE1_MedKeog-gA5DSehzDpOsYBtSD2PwycsuXy524zZfJmYEPWiQSJFc95wvb-idkje44ECONglHCXZCwwrzqAMPSA1gAr73q9J5UuS-nJzMldYgvzQZKPRUJR1VVDSeBj6lfR4V1boTpI_s677-k-no_l89ijs.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114833/imgi_60_APNQkAEv0bo7lMmZnil5-9LSxTWVFJ-S_m9GmyrX4JHAyAjyoSSrwu4xT7GPbtWwITwTlvruhM9M9e7v7A9onjYhyx6D4Pb3_TPn561pjA7e3OpbY_VLEPBKXGmm6BxTJqiMknUIxxmuidN0kCfh_s677-k-no_itc5i5.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114813/imgi_32_APNQkAEgjpqG4zEpbPT3VCB7BINlXAlDYRAbpUY9HNnGegIr3AqvHd7Y-08VFn64XxiwN_QtrpHbhpYos3pTeRgZBN-EZ00IDUsSzxUP3u4JUqMDjeSrDqcxPeJ2m3rMJCzvNGEK64DZwRwkLqJP_w203-h270-k-no_jopn28.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114813/imgi_29_APNQkAErquEgBWpg9DfZQTl6EtvjudMskwXgeDy9BNvsuhzgLcqRA7oCw5zG9hkKFyWU3LDvB6tWus79rOlO-4SSZh2YMioPDhKNL7VGN3nQsdVl2dAvHRMrRCMk4MYeihaK1oFd69MYz05HdzYi_s677-k-no_eefioe.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114816/imgi_38_APNQkAEyd_yxYhRb7GF3ZCiDcRXn_fNyU_hLxxEbf11Vww7gDKTIkqI8tuFQAUcY8RVtbOACe5RQIZgpnVY7Tb3ilyNs7R7-lA6NQuxI1QfCs5OunveSPMaT_ZZ2RWPFOoKLJ9Gh27zlLmAjYjl9_w203-h270-k-no_vg6acw.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114818/imgi_45_APNQkAGNMYePg1BxZqXcM7WyEhC3srYtCKt_Yb37fDF7gAo8NfagIBY_FJaZDF6oEv-LVsMF_SV6B6NkYTqkT1ART0cNXC5wTcO4xHVpVJKDsGNU3lEhvTbFFLE5rxwGAHGHFCg5_XijOlLSXDE_s406-k-no_kqz7z8.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114823/imgi_56_APNQkAG_AaWavciiztjsgjjtbG_Urh1VVl3ky9YaNI2Aq35xxyo1qNxKz9EAmW83UbvVChwUkZ5zvcpogsmhvs9PNhK7LRDZnlxHhYZImh0Ellxgu9BwRK7-br1XMI_eiZUeqmVp4BQpBV5q3c-B_s406-k-no_fruqpc.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114823/imgi_48_APNQkAEBppH_1prUiKYT0wmI_wyEAKLeEOBMCRbhhVTS-FyAGn2T-jFZQZWVy891Ron7Y4TzuQGyA7qPuarhLlZUmdytniI2upAvTG-1UIGP_xjzcWU-i0q2XMj6fRbWbwd4CKVQUs-017EQrNUU_s677-k-no_ndcbsj.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114834/imgi_91_APNQkAGdV9gm_D9XDSGNbdYbxtSjFNk3xDccji1fbCL2Df3IJ89jAahA56pxM-eR0wf1SXU5RZ-eL7cFLeE419gzPTVo4wBWJO20s1J2n4-ayCVOjUO6tCl3HmufLl4bmw7w30iDjDdBgdrW89A_s677-k-no_swd8ep.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114836/imgi_88_APNQkAHaQnhdk7R8i2Yb4a0crWqvfsc4tM_e2EwTkMX2Hl_gv7HKeJPSQOZ5FdXR-kyhhMPZc3ScT817Ry76Jt5_RvQWTtzzYx3hsf4xhNOcTMfd3ixInW-SBFeLHxtq94eFOqdjxD2gcV3YXfvy_s508-k-no_n2rckn.jpg',
];

/* ──────────── MENU IMAGES (4 slots) ──────────── */
const MENU_IMAGES = [
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114806/imgi_27_AF1QipMHTB41I1NfuT-Fyqk9yIDqxj68MXW5WF89PUcW_s677-k-no_1_pprazd.png',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114811/imgi_31_AF1QipMxCMO62OKea795f6fYkJrx3Sc7ZsdTypVvklv7_s677-k-no_vcu7rb.png',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114816/imgi_27_AF1QipMHTB41I1NfuT-Fyqk9yIDqxj68MXW5WF89PUcW_s677-k-no_j3afyw.png',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114832/imgi_23_AF1QipPXFaW2gMxy9pn74lHjS0Tr47M85axOxdkx0ToZ_s677-k-no_y0e3lt.png',
];

/* ──────────── BLOG IMAGES ──────────── */
const BLOG_IMAGES = [
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114829/imgi_43_APNQkAFBdrwzYJ-SA-922weJ_UP3Wyohx2emd8LVJ7N_v3Jz_43hYAol1DyV0L8qmWDQBAGamz7NV6o_fYdLtaYBjLUTiIViFxlktGRC8ANG6XdevZy6W4J4EL8WbpBxL4I9a10f8GYfQ_6al9Zj_s406-k-no_zav1si.png',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114830/imgi_62_APNQkAE1_MedKeog-gA5DSehzDpOsYBtSD2PwycsuXy524zZfJmYEPWiQSJFc95wvb-idkje44ECONglHCXZCwwrzqAMPSA1gAr73q9J5UuS-nJzMldYgvzQZKPRUJR1VVDSeBj6lfR4V1boTpI_s677-k-no_l89ijs.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114821/imgi_52_APNQkAHK_atRSUItYRhDpdQJqeqCNjpYnIEpIvJCIYJGNz0GQRl5Q1Qnj9HaCoQV550sDICuXdxWOXRJGjUfJY0bjOdRXq15HXFhHm5_wwxVG1JKyadu7cx9JROEAThevLoDlBxg2m4nGhV3SU9E_s677-k-no_pfbqe5.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114816/imgi_36_APNQkAHZAjFe8azo2NAzXXO-Em0bCL9twjlj3WV8jO5Ossl-UNWddcpKpoqTjnCipsjghvaPp8CECsIcqBG2DSceDGoB4HWEK1k-JLrwiKZhypdo1v82Vw2CXCm8tr2HGilQmnLxUVvV2DiStfhk_s387-k-no_mqnusa.jpg',
  'https://res.cloudinary.com/dzdmcmonz/image/upload/v1779114836/imgi_88_APNQkAHaQnhdk7R8i2Yb4a0crWqvfsc4tM_e2EwTkMX2Hl_gv7HKeJPSQOZ5FdXR-kyhhMPZc3ScT817Ry76Jt5_RvQWTtzzYx3hsf4xhNOcTMfd3ixInW-SBFeLHxtq94eFOqdjxD2gcV3YXfvy_s508-k-no_n2rckn.jpg',
];

/* ──────────── REVEAL ON SCROLL ──────────── */
function Reveal({ children, className = '' }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('visible'); obs.unobserve(el); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}

/* ════════════════════════════════════════════════════════
   LIGHTBOX
   ════════════════════════════════════════════════════════ */
function Lightbox({ src, onClose, onPrev, onNext }: { src: string; onClose: () => void; onPrev: () => void; onNext: () => void }) {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKey);
    };
  }, [onClose, onPrev, onNext]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <button
        onClick={(e) => { e.stopPropagation(); onClose(); }}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 text-white/70 hover:text-white transition-colors z-10"
      >
        <X size={32} />
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onPrev(); }}
        className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors z-10"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onNext(); }}
        className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors z-10"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6"/></svg>
      </button>
      <img
        src={src}
        alt="Galerie Côté Plage"
        className="max-h-[90vh] max-w-[95vw] object-contain rounded-lg shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      />
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   NAVBAR
   ════════════════════════════════════════════════════════ */
function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  const links = [
    { href: '#accueil', label: 'Accueil' },
    { href: '#galerie', label: 'Galerie' },
    { href: '#menu', label: 'Menu' },
    { href: '#avis', label: 'Avis' },
    { href: '#blog', label: 'Blog' },
    { href: '#localisation', label: 'Nous Trouver' },
  ];

  return (
    <nav
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-lg shadow-lg'
          : 'bg-gradient-to-b from-black/40 to-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <a href="#accueil" className="flex items-center gap-3 group">
            <div className="flex flex-col">
              <span
                className={`text-2xl sm:text-3xl font-serif font-bold tracking-tight transition-colors ${
                  scrolled ? 'text-brown' : 'text-white'
                }`}
              >
                Côté{' '}
                <span className={scrolled ? 'text-terracotta' : 'text-terracotta-light'}>
                  Plage
                </span>
              </span>
              <span
                className={`text-[10px] tracking-[0.25em] uppercase -mt-1 transition-colors ${
                  scrolled ? 'text-brown-light' : 'text-white/70'
                }`}
              >
                Café &amp; Restaurant
              </span>
            </div>
          </a>

          <div className="hidden lg:flex items-center gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className={`px-3 py-2 rounded-lg text-sm font-medium tracking-wide transition-colors ${
                  scrolled
                    ? 'text-brown/70 hover:text-terracotta hover:bg-cream'
                    : 'text-white/85 hover:text-white hover:bg-white/10'
                }`}
              >
                {l.label}
              </a>
            ))}
            <a
              href={waLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-4 flex items-center gap-2 bg-forest text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-forest-dark transition-all hover:shadow-lg active:scale-95"
            >
              <MessageCircle size={16} />
              Réserver
            </a>
          </div>

          <button
            onClick={() => setOpen(!open)}
            className={`lg:hidden p-2 rounded-xl transition-colors ${
              scrolled ? 'text-brown hover:bg-cream' : 'text-white hover:bg-white/10'
            }`}
          >
            {open ? <X size={26} /> : <MenuIcon size={26} />}
          </button>
        </div>
      </div>

      <div
        className={`lg:hidden overflow-hidden transition-all duration-400 ease-in-out ${
          open ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-white/98 backdrop-blur-lg border-t border-cream px-4 py-3 space-y-1 shadow-2xl">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block px-4 py-3 text-brown/75 hover:text-terracotta hover:bg-cream/60 rounded-xl transition-colors font-medium"
            >
              {l.label}
            </a>
          ))}
          <a
            href={waLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-forest text-white px-5 py-3 rounded-full font-semibold mt-3"
          >
            <MessageCircle size={18} />
            Réserver sur WhatsApp
          </a>
        </div>
      </div>
    </nav>
  );
}

/* ════════════════════════════════════════════════════════
   HERO
   ════════════════════════════════════════════════════════ */
function Hero() {
  return (
    <section
      id="accueil"
      className="relative h-screen min-h-[650px] flex items-center justify-center overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center scale-105"
        style={{ backgroundImage: `url(${HERO_IMG})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-brown/80" />

      <div className="absolute top-20 right-10 w-64 h-64 rounded-full bg-terracotta/10 blur-3xl animate-float" />
      <div className="absolute bottom-20 left-10 w-48 h-48 rounded-full bg-forest/15 blur-3xl animate-float" style={{ animationDelay: '3s' }} />

      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-5 py-2 rounded-full mb-8 animate-fade-in">
          <Sparkles size={14} className="text-yellow-300" />
          <span className="text-xs sm:text-sm tracking-[0.2em] uppercase font-medium">
            Café &amp; Restaurant en Bord de Mer
          </span>
          <Sparkles size={14} className="text-yellow-300" />
        </div>

        <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-serif font-bold mb-6 leading-[0.9] animate-slide-up">
          Côté
          <br />
          <span className="text-terracotta-light">Plage</span>
        </h1>

        <p className="text-base sm:text-lg md:text-xl text-white/75 mb-12 max-w-2xl mx-auto leading-relaxed font-light animate-fade-in" style={{ animationDelay: '0.3s' }}>
          Un cadre exceptionnel au bord de la mer, des saveurs authentiques
          <br className="hidden sm:block" />
          et des moments inoubliables
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '0.6s' }}>
          <a
            href={waLink('Bonjour ! Je souhaite réserver une table chez Côté Plage.')}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto flex items-center justify-center gap-3 bg-forest text-white px-8 py-4 rounded-full text-base sm:text-lg font-semibold hover:bg-forest-dark transition-all duration-300 hover:shadow-2xl hover:scale-[1.03] active:scale-95"
          >
            <MessageCircle size={20} />
            Réserver une Table
          </a>
          <a
            href="#menu"
            className="w-full sm:w-auto flex items-center justify-center gap-3 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full text-base sm:text-lg font-medium hover:bg-white/20 transition-all border border-white/25"
          >
            <UtensilsCrossed size={20} />
            Voir le Menu
          </a>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 hover:text-white transition-colors animate-bounce"
      >
        <ChevronDown size={36} />
      </a>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   ABOUT / TRUST SECTION
   ════════════════════════════════════════════════════════ */
function About() {
  const features = [
    { icon: <Waves size={26} />, title: 'Vue sur la Mer', desc: "Emplacement pieds dans l'eau" },
    { icon: <Coffee size={26} />, title: 'Produits Frais', desc: 'Ingrédients locaux & de saison' },
    { icon: <Award size={26} />, title: 'Service Premium', desc: 'Accueil chaleureux & attentif' },
    { icon: <Heart size={26} />, title: 'Cadre Unique', desc: 'Ambiance cozy & élégante' },
  ];

  return (
    <section id="about" className="py-16 sm:py-24 bg-cream">
      <div className="max-w-6xl mx-auto px-4">
        <Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-10">
            {features.map((f, i) => (
              <div key={i} className="text-center group cursor-default">
                <div className="mx-auto mb-4 w-16 h-16 rounded-2xl bg-forest/10 text-forest flex items-center justify-center group-hover:bg-forest group-hover:text-white group-hover:rounded-full transition-all duration-400 group-hover:scale-110 group-hover:shadow-lg">
                  {f.icon}
                </div>
                <h3 className="text-brown font-serif font-bold text-sm sm:text-base mb-1">{f.title}</h3>
                <p className="text-brown-light/60 text-xs sm:text-sm">{f.desc}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal className="mt-16">
          <div className="relative bg-forest rounded-3xl p-8 sm:p-12 text-center overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute -top-10 -right-10 w-60 h-60 rounded-full bg-terracotta blur-3xl" />
              <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-white blur-3xl" />
            </div>
            <div className="relative">
              <h3 className="text-white font-serif text-2xl sm:text-3xl font-bold mb-3">
                Une expérience culinaire inoubliable
              </h3>
              <p className="text-white/70 mb-8 max-w-xl mx-auto text-sm sm:text-base">
                Laissez-vous tenter par notre carte variée, des boissons chaudes aux fruits de mer frais, le tout avec une vue imprenable.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href={waLink('Bonjour ! Je souhaite réserver une table.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-white text-forest px-7 py-3.5 rounded-full font-semibold hover:bg-cream transition-all hover:shadow-xl active:scale-95"
                >
                  <MessageCircle size={18} />
                  Réserver Maintenant
                </a>
                <a
                  href={`tel:${PHONE_DISPLAY}`}
                  className="flex items-center gap-2 text-white/90 hover:text-white px-7 py-3.5 font-medium transition-colors"
                >
                  <Phone size={18} />
                  {PHONE_DISPLAY}
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   GALLERY – 17 real images with lightbox
   ════════════════════════════════════════════════════════ */
function Gallery() {
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const openLightbox = (i: number) => setLightboxIdx(i);
  const closeLightbox = () => setLightboxIdx(null);
  const goPrev = () => setLightboxIdx((prev) => (prev !== null ? (prev - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length : null));
  const goNext = () => setLightboxIdx((prev) => (prev !== null ? (prev + 1) % GALLERY_IMAGES.length : null));

  return (
    <section id="galerie" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="text-terracotta text-xs sm:text-sm tracking-[0.25em] uppercase font-semibold">
              Notre Espace
            </span>
            <h2 className="text-brown font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mt-3">
              Galerie
            </h2>
            <div className="w-20 h-1 bg-terracotta mx-auto mt-4 rounded-full" />
          </div>
        </Reveal>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {GALLERY_IMAGES.map((src, i) => (
            <Reveal key={i}>
              <div
                className="relative group cursor-pointer overflow-hidden rounded-2xl shadow-sm hover:shadow-xl transition-all duration-500"
                onClick={() => openLightbox(i)}
              >
                <img
                  src={src}
                  alt={`Côté Plage - Photo ${i + 1}`}
                  className="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-14 h-14 rounded-full bg-white/25 backdrop-blur-sm flex items-center justify-center">
                    <Camera size={24} className="text-white" />
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {lightboxIdx !== null && (
        <Lightbox
          src={GALLERY_IMAGES[lightboxIdx]}
          onClose={closeLightbox}
          onPrev={goPrev}
          onNext={goNext}
        />
      )}
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   MENU SECTION – 4 menu image cards
   ════════════════════════════════════════════════════════ */
function MenuSection() {

  return (
    <section id="menu" className="py-16 sm:py-24 bg-cream">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="text-terracotta text-xs sm:text-sm tracking-[0.25em] uppercase font-semibold">
              Nos Saveurs
            </span>
            <h2 className="text-brown font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mt-3">
              Le Menu
            </h2>
            <div className="w-20 h-1 bg-terracotta mx-auto mt-4 rounded-full" />
            <p className="mt-6 text-brown-light/60 max-w-lg mx-auto text-sm sm:text-base">
              Découvrez notre carte complète préparée avec des produits frais et locaux, pour vous offrir le meilleur de la cuisine méditerranéenne.
            </p>
          </div>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
          {MENU_IMAGES.map((src, i) => (
            <Reveal key={i}>
              <div className="group relative overflow-hidden rounded-2xl shadow-md hover:shadow-2xl transition-all duration-500 bg-white">
                <div className="aspect-[3/4] overflow-hidden">
                  <img
                    src={src}
                    alt={`Menu Côté Plage - Page ${i + 1}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center">
          <a
            href={waLink('Bonjour ! Je souhaite consulter le menu ou passer une commande.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-forest text-white px-8 py-4 rounded-full text-base sm:text-lg font-semibold hover:bg-forest-dark transition-all duration-300 hover:shadow-xl active:scale-95"
          >
            <MessageCircle size={20} />
            Commander via WhatsApp
          </a>
        </Reveal>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   REVIEWS
   ════════════════════════════════════════════════════════ */
function Reviews() {
  const reviews = [
    {
      name: 'Sophie M.',
      text: "Un cadre magnifique en bord de mer. Le café est excellent et le personnel très accueillant. Je recommande vivement ce restaurant !",
      rating: 5,
    },
    {
      name: 'Ahmed B.',
      text: "La nourriture est exceptionnelle et fraîche. Le poisson grillé est le meilleur que j'ai goûté. Vue imprenable sur l'océan !",
      rating: 5,
    },
    {
      name: 'Marie L.',
      text: "Très bon restaurant avec une vue spectaculaire. Les prix sont raisonnables et le service est rapide. On y retourne chaque week-end.",
      rating: 5,
    },
    {
      name: 'Karim E.',
      text: "Le meilleur endroit pour un café face à la mer. L'ambiance est relaxante et les smoothies sont délicieux. Mon lieu préféré !",
      rating: 5,
    },
    {
      name: 'Julie R.',
      text: "Service impeccable et plats délicieux. Le coucher de soleil depuis la terrasse est tout simplement magique. Bravo à toute l'équipe !",
      rating: 5,
    },
    {
      name: 'Youssef T.',
      text: "Restaurant de qualité avec un personnel professionnel. Le tagine de fruits de mer est à tomber ! Excellent rapport qualité-prix.",
      rating: 5,
    },
  ];

  return (
    <section id="avis" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="text-terracotta text-xs sm:text-sm tracking-[0.25em] uppercase font-semibold">
              Témoignages
            </span>
            <h2 className="text-brown font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mt-3">
              Avis Clients
            </h2>
            <div className="w-20 h-1 bg-terracotta mx-auto mt-4 rounded-full" />
            <div className="flex items-center justify-center gap-1 mt-6">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} size={24} className="text-yellow-400 fill-yellow-400" />
              ))}
              <span className="ml-3 text-brown font-bold text-lg">4.9/5</span>
              <span className="text-brown-light/50 text-sm ml-2">sur Google</span>
            </div>
          </div>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {reviews.map((r, i) => (
            <Reveal key={i}>
              <div className="bg-cream rounded-2xl p-6 sm:p-7 hover:shadow-xl transition-all duration-400 group relative overflow-hidden">
                <Quote size={40} className="absolute top-4 right-4 text-terracotta/10" />
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: r.rating }).map((_, s) => (
                    <Star key={s} size={15} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-brown/65 text-sm leading-relaxed mb-5 min-h-[60px]">
                  &ldquo;{r.text}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-forest text-white flex items-center justify-center font-bold text-sm">
                    {r.name.charAt(0)}
                  </div>
                  <div>
                    <span className="text-brown font-semibold text-sm block">{r.name}</span>
                    <span className="text-brown-light/40 text-xs">Client vérifié</span>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center">
          <a
            href={MAPS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-forest hover:text-forest-dark transition-colors font-semibold group"
          >
            <Star size={18} className="group-hover:fill-yellow-400 group-hover:text-yellow-400 transition-colors" />
            Laisser votre avis sur Google
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   BLOG – 5 posts with real images
   ════════════════════════════════════════════════════════ */
function BlogSection() {
  const posts = [
    {
      title: 'Découvrez Côté Plage : Le Meilleur Café-Restaurant en Bord de Mer',
      excerpt:
        "Niché au bord de la plage, Côté Plage vous offre une expérience culinaire unique avec une vue imprenable sur l'océan. Découvrez notre histoire et notre passion pour la gastronomie méditerranéenne.",
      tag: 'Découverte',
    },
    {
      title: 'Notre Carte : Des Plats Frais Préparés avec Amour',
      excerpt:
        "Chez Côté Plage, chaque plat est préparé avec des ingrédients frais et locaux. Notre chef vous propose une carte variée allant des fruits de mer aux grillades en passant par nos desserts faits maison.",
      tag: 'Gastronomie',
    },
    {
      title: "L'Expérience Plage : Déguster un Café face à la Mer",
      excerpt:
        "Imaginez-vous savourant un cappuccino crémeux tout en écoutant le bruit des vagues. C'est l'expérience unique que nous offrons chaque jour à nos clients chanceux.",
      tag: 'Expérience',
    },
    {
      title: 'Événements & Célébrations chez Côté Plage',
      excerpt:
        "Vous organisez un anniversaire, une fête ou un événement professionnel ? Notre espace est parfait pour vos célébrations avec un cadre de rêve en bord de mer et un service sur mesure.",
      tag: 'Événements',
    },
    {
      title: 'Les 5 Raisons de Visiter Côté Plage cet Été',
      excerpt:
        "Vue panoramique sur la plage, cuisine fraîche et savoureuse, ambiance relaxante, service exceptionnel et cocktails rafraîchissants. Voici pourquoi nous sommes votre destination estivale idéale.",
      tag: 'Été 2025',
    },
  ];

  return (
    <section id="blog" className="py-16 sm:py-24 bg-cream">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="text-terracotta text-xs sm:text-sm tracking-[0.25em] uppercase font-semibold">
              Actualités
            </span>
            <h2 className="text-brown font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mt-3">
              Blog
            </h2>
            <div className="w-20 h-1 bg-terracotta mx-auto mt-4 rounded-full" />
          </div>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {posts.map((post, i) => (
            <Reveal key={i}>
              <article className="bg-white rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-400 group h-full flex flex-col">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={BLOG_IMAGES[i]}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                  <span className="absolute top-3 left-3 bg-terracotta text-white text-[10px] sm:text-xs px-3 py-1 rounded-full font-semibold tracking-wide">
                    {post.tag}
                  </span>
                </div>
                <div className="p-5 sm:p-6 flex flex-col flex-1">
                  <h3 className="text-brown font-serif font-bold text-base sm:text-lg mb-3 leading-snug group-hover:text-terracotta transition-colors duration-300">
                    {post.title}
                  </h3>
                  <p className="text-brown-light/55 text-sm leading-relaxed mb-4 flex-1">
                    {post.excerpt}
                  </p>
                  <span className="inline-flex items-center gap-1 text-forest text-sm font-semibold cursor-pointer group/link">
                    Lire la suite
                    <ArrowRight
                      size={14}
                      className="group-hover/link:translate-x-1 transition-transform"
                    />
                  </span>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   LOCATION / CONTACT
   ════════════════════════════════════════════════════════ */
function LocationSection() {
  const info = [
    {
      icon: <MapPin size={20} className="text-forest" />,
      title: 'Adresse',
      detail: ADDRESS,
      action: MAPS_URL,
      actionLabel: ADDRESS,
    },
    {
      icon: <Phone size={20} className="text-forest" />,
      title: 'Téléphone',
      detail: PHONE_DISPLAY,
      action: `tel:${PHONE_DISPLAY}`,
      actionLabel: PHONE_DISPLAY,
    },
    {
      icon: <Clock size={20} className="text-forest" />,
      title: "Horaires",
      detail: 'Lundi – Dimanche : 8h00 – 23h00',
    },
    {
      icon: <MessageCircle size={20} className="text-forest" />,
      title: 'WhatsApp',
      detail: 'Réponse rapide garantie',
      action: waLink(),
      actionLabel: 'Envoyer un message',
    },
  ];

  return (
    <section id="localisation" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <span className="text-terracotta text-xs sm:text-sm tracking-[0.25em] uppercase font-semibold">
              Nous Trouver
            </span>
            <h2 className="text-brown font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mt-3">
              Localisation
            </h2>
            <div className="w-20 h-1 bg-terracotta mx-auto mt-4 rounded-full" />
          </div>
        </Reveal>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Google Maps embed */}
          <Reveal>
            <div className="rounded-3xl overflow-hidden shadow-lg h-[420px] lg:h-full min-h-[420px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3399.0!2d-9.6!3d30.4!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzDCsDI0JzAwLjAiTiA5wrAzNicwMC4wIlc!5e0!3m2!1sfr!2sma!4v1700000000000"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Localisation Côté Plage"
                className="w-full h-full"
              />
            </div>
          </Reveal>

          {/* Contact info cards */}
          <div className="flex flex-col gap-4">
            {info.map((item, i) => (
              <Reveal key={i}>
                <div className="bg-cream rounded-2xl p-5 sm:p-6 flex items-center gap-4 group hover:shadow-md transition-shadow duration-300">
                  <div className="w-12 h-12 rounded-xl bg-forest/10 flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-brown font-bold text-sm sm:text-base">{item.title}</h4>
                    {item.action ? (
                      <a
                        href={item.action}
                        target={item.action.startsWith('http') ? '_blank' : undefined}
                        rel={item.action.startsWith('http') ? 'noopener noreferrer' : undefined}
                        className="text-terracotta text-sm hover:underline font-medium break-all"
                      >
                        {item.actionLabel}
                      </a>
                    ) : (
                      <p className="text-brown-light/60 text-sm">{item.detail}</p>
                    )}
                  </div>
                </div>
              </Reveal>
            ))}

            <Reveal>
              <a
                href={waLink('Bonjour ! Je souhaite réserver une table chez Côté Plage.')}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 bg-forest text-white px-8 py-4 rounded-2xl text-base sm:text-lg font-semibold hover:bg-forest-dark transition-all duration-300 hover:shadow-xl mt-2 active:scale-[0.98]"
              >
                <MessageCircle size={22} />
                Contactez-nous sur WhatsApp
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════════════════════
   FOOTER
   ════════════════════════════════════════════════════════ */
function Footer() {
  const navLinks = [
    { href: '#accueil', label: 'Accueil' },
    { href: '#galerie', label: 'Galerie' },
    { href: '#menu', label: 'Menu' },
    { href: '#avis', label: 'Avis' },
    { href: '#blog', label: 'Blog' },
    { href: '#localisation', label: 'Localisation' },
  ];

  return (
    <footer className="bg-brown text-white">
      <div className="h-1 bg-gradient-to-r from-terracotta via-forest to-terracotta" />

      <div className="max-w-7xl mx-auto px-4 py-12 sm:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 sm:gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <h3 className="text-2xl sm:text-3xl font-serif font-bold mb-1">
              Côté <span className="text-terracotta">Plage</span>
            </h3>
            <p className="text-white/40 text-xs tracking-[0.15em] uppercase mb-5">
              Café &amp; Restaurant
            </p>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-xs">
              Votre destination en bord de mer pour des moments de détente et de
              gastronomie inoubliables.
            </p>
            <div className="flex gap-2.5">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-terracotta transition-colors duration-300"
                aria-label="Instagram"
              >
                <InstagramIcon size={17} />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-terracotta transition-colors duration-300"
                aria-label="Facebook"
              >
                <FacebookIcon size={17} />
              </a>
              <a
                href={waLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-green-600 transition-colors duration-300"
                aria-label="WhatsApp"
              >
                <MessageCircle size={17} />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-bold text-sm tracking-wide uppercase text-white/70 mb-5">
              Navigation
            </h4>
            <ul className="space-y-2.5">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-white/45 text-sm hover:text-terracotta transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-terracotta/40 group-hover:bg-terracotta transition-colors" />
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Horaires */}
          <div>
            <h4 className="font-bold text-sm tracking-wide uppercase text-white/70 mb-5">
              Horaires
            </h4>
            <ul className="space-y-2.5 text-sm text-white/45">
              <li className="flex justify-between">
                <span>Lundi – Vendredi</span>
                <span className="text-white/60">8h – 23h</span>
              </li>
              <li className="flex justify-between">
                <span>Samedi</span>
                <span className="text-white/60">8h – 00h</span>
              </li>
              <li className="flex justify-between">
                <span>Dimanche</span>
                <span className="text-white/60">8h – 23h</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-sm tracking-wide uppercase text-white/70 mb-5">
              Contact
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href={`tel:${PHONE_DISPLAY}`}
                  className="flex items-center gap-2.5 text-white/45 text-sm hover:text-terracotta transition-colors"
                >
                  <Phone size={14} />
                  {PHONE_DISPLAY}
                </a>
              </li>
              <li>
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-2.5 text-white/45 text-sm hover:text-terracotta transition-colors"
                >
                  <MapPin size={14} className="shrink-0 mt-0.5" />
                  <span>{ADDRESS}</span>
                </a>
              </li>
              <li>
                <a
                  href={waLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 text-white/45 text-sm hover:text-green-400 transition-colors"
                >
                  <MessageCircle size={14} />
                  WhatsApp
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-xs">
            © {new Date().getFullYear()} Côté Plage. Tous droits réservés.
          </p>
          <a
            href={waLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-white/40 text-xs hover:text-green-400 transition-colors"
          >
            <MessageCircle size={14} />
            Réservez sur WhatsApp
          </a>
        </div>
      </div>
    </footer>
  );
}

/* ════════════════════════════════════════════════════════
   FLOATING WHATSAPP BUTTON
   ════════════════════════════════════════════════════════ */
function WhatsAppFloat() {
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowTooltip(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3">
      <div
        className={`bg-white text-brown text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg font-medium transition-all duration-500 max-w-[180px] ${
          showTooltip ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4 pointer-events-none'
        }`}
      >
        <span>Besoin d'aide ?</span>
        <button
          onClick={() => setShowTooltip(false)}
          className="ml-2 text-brown/40 hover:text-brown"
        >
          <X size={12} />
        </button>
      </div>

      <a
        href={waLink()}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-green-500 text-white rounded-full shadow-2xl hover:bg-green-600 transition-all duration-300 hover:scale-110 animate-pulse-slow active:scale-95"
        aria-label="Contactez-nous sur WhatsApp"
      >
        <MessageCircle size={26} />
      </a>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   APP
   ════════════════════════════════════════════════════════ */
export default function App() {
  return (
    <div className="font-sans antialiased">
      <Navbar />
      <Hero />
      <About />
      <Gallery />
      <MenuSection />
      <Reviews />
      <BlogSection />
      <LocationSection />
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}
